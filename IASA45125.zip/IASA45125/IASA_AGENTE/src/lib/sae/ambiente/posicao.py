"""
Posição do ambiente
@author: Luís Morgado
"""

Posicao = tuple[int, int]
"""Tipo que define uma posição do ambiente"""