from abc import ABC

"""
Classe que representa interface do avaliador
"""
class Avaliador(ABC):

    def prioridade(self, no):
        pass
